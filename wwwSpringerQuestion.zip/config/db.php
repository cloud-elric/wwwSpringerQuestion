<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=springer_questions',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
