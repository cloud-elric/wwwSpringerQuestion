<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?= Yii::$app->charset ?>" />
    <title>Recuperar contraseña</title>
</head>
<body>
<header>

</header>
<section>
<h1>Recuperar contraseña</h1>

<p>Hola <?=$user?></p>
<p>Hemos visto que recientemente haz solicitado una nueva contraseña.
Resetea tu contraseña desde este <a href='<?=$url?>'>link</a>
</p>
<p>-Equipo 2 Geeks one Monkey</p>
</section>
<footer>


</footer>


</body>
</html>
