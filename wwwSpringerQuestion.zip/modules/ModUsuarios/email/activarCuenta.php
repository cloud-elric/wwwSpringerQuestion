<?php 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type"
	content="text/html; charset=<?= Yii::$app->charset ?>" />
<title>Activación de cuenta</title>
</head>
<body>
	<header> </header>
	<section>
		<h1>Activación de cuenta</h1>

		<p>Bienvenido <?=$user?></p>
		<p>Pass: <?=$pass?></p>
		<p>
			Para activar tu cuenta hazlo desde este <a
				href='<?=$url?>'>link</a>
		</p>
		<p>-Equipo 2 Geeks one Monkey</p>
	</section>
	<footer> </footer>


</body>
</html>
